// header guard
#ifndef PersonNode_H
#define PersonNode_H

#include <iostream>
#include <string>

using namespace std;

class PersonNode
{
public:
    PersonNode(string, string);     // Constructor, 2 parameters
    PersonNode(const PersonNode *); // Constructor, copy
    ~PersonNode();                  // Destructor
    PersonNode *getNextContact();   // Return pointer next node
    void printPersonNode();         // Display string data of node

    // declaring non member functions as friends to access private
    // members of PersonNode
    friend void insertNextTo(PersonNode*, PersonNode*);
    friend void deleteList(PersonNode*);
private:
    string contactName;     // Name
    string contactPhoneNum; // Phone
    PersonNode *nextNode;   // Link to next
};

#endif