#include "PersonNode.h"

// implement member functions

PersonNode::PersonNode(string name, string number) {
    // assign variables
    contactName = name;
    contactPhoneNum = number;
    nextNode = nullptr;
}

PersonNode::PersonNode(const PersonNode * other) {
    // set name and phonenum same as other
    contactName = other->contactName;
    contactPhoneNum = other->contactPhoneNum;
    nextNode = other->nextNode;
}

PersonNode::~PersonNode() {
    // clear name and contactNum
    contactName = "";
    contactPhoneNum = "";
    // set next pointer to null
    nextNode = nullptr;
}

PersonNode * PersonNode::getNextContact() {
    // return nextNode
    return nextNode;
}

void PersonNode::printPersonNode() {
    // print
    cout << contactName << ": " << contactPhoneNum << endl;
}

void insertNextTo(PersonNode* first, PersonNode* second) {
    // if nextNode of first is null then just add
    if(first->nextNode == nullptr) {
        first->nextNode = second;
    }
    else {
        // set the next of second to next of first
        second->nextNode = first->nextNode;
        // update nextnode of first
        first->nextNode = second;
    }
  
}

void deleteList(PersonNode* node) {
    // use recursion to delete from tail first
    if (node != nullptr) {
        // go to next node
        deleteList(node->getNextContact());
        // delete this node
        delete node;
    }
}